﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labash
{
    public partial class Form1 : Form
    {
        
        private const int _fieldWidth = 3;
        private const int _fieldHeight = 3;
        private const int _cellSize = 100;
        private const int _minesAmount = 3;


        private int[,] _fieldInfo;
        private Button[,] _fieldButtons;


        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;
        }

      
        private void Form1_Load(object sender, EventArgs e)
        {

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Text = "Минёр";

            initGame();
        }

        private void initGame()
        {
            
            clearField();

            
            this.ClientSize = new Size(_cellSize * _fieldWidth, _cellSize * _fieldHeight);

            
            _fieldInfo = new int[_fieldHeight, _fieldWidth];

            
            _fieldButtons = new Button[_fieldHeight, _fieldWidth];


            
            for (int i = 0; i < _fieldHeight; i++)
            {
                for (int j = 0; j < _fieldWidth; j++)
                {
                    Button b = new Button();
                    b.Width = _cellSize;
                    b.Height = _cellSize;
                    b.Location = new Point(j * _cellSize, i * _cellSize);

                    
                    int iTemp = i;
                    int jTemp = j;
                    b.Click += (sen, evArg) =>
                    {
                        B_Click(iTemp, jTemp);
                    };


                    
                    Controls.Add(b);
                    _fieldButtons[i, j] = b;
                }
            }


            
            Random random = new Random();
            int mines = _minesAmount;

            while (mines > 0)
            {
                int randX = random.Next(0, _fieldWidth);
                int randY = random.Next(0, _fieldHeight);

                if (_fieldInfo[randY, randX] == 0)
                {
                    _fieldInfo[randY, randX] = 666;
                    
                    mines--;
                }
            }
        }

        private void clearField()
        {
            if (_fieldButtons != null)
            {
                foreach (Button button in _fieldButtons)
                {
                    Controls.Remove(button);
                }
            }
        }

      
        private void B_Click(int i, int j)
        {
            
            Button b = _fieldButtons[i, j];
            if (_fieldInfo[i, j] == 666)
            {
                b.BackColor = Color.Red;
                b.Text = "МИНА!!!";

                MessageBox.Show("Вы проиграли!");
                initGame();
                return;
            }


            int minesAroundCount = 0;

            for (int y = i - 1; y <= i + 1; y++)
            {
                for (int x = j - 1; x <= j + 1; x++)
                {
                    
                    if (y == i && x == j) continue;

                    
                    if (!(y >= 0 && y < _fieldHeight) || !(x >= 0 && x < _fieldWidth)) continue;

                    
                    if (_fieldInfo[y, x] == 666)
                    {
                        minesAroundCount++;
                    }

                }
            }

            b.Text = minesAroundCount.ToString();
        }
    }
}